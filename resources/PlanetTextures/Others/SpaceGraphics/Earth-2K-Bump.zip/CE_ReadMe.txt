COMPLEMENTARY EARTH Map by www.Space-Graphics.com
---------------------------------------

Map type = Bump / 8bit
Version = 1.0
Build date = Oct-25-2002
Map size = 2700 x 1350 px
Spherically map-able = Yes
Seamless = Yes

For more information: www.space-graphics.com

-----------------------------------------------------------------------
USAGE LICENCE
-----------------------------------------------------------------------
This map is distributed as FREEWARE for Personal use only
NO Commercial use or Commercial redistribution allowed in any form.

Science / Astronomy Publications, Journals and Magazines are entitled for
a FREE license.

For more informations, please email: licensing@space-graphics.com

-----------------------------------------------------------------------
COMMENTS - SUGGESTIONS - INFORMATIONS
-----------------------------------------------------------------------
Your suggestions, thoughts and comments are an invaluable resource and 
are greatly appreciated. You can send your feedback to :

info@space-graphics.com